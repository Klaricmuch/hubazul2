
  # Marketplace Development

  This is a code bundle for Marketplace Development. The original project is available at https://www.figma.com/design/QjU19fujKAKAEioIkU0bey/Marketplace-Development.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  