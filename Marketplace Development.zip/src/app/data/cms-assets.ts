import { Asset } from '../types/cms-schema';

/**
 * Mock CMS Data - R&D Assets
 * In production, this data would come from a headless CMS
 */
export const cmsAssets: Asset[] = [
  {
    id: 'asset-001',
    slug: 'marine-robotics-testing-tank',
    name: 'Marine Robotics Testing Tank',
    assetType: 'infrastructure-with-support',
    subType: 'laboratory',
    requiresTechnicalSupport: true,
    accessScope: 'both',
    institution: 'Atlantic Marine Research Institute',
    city: 'Lisboa',
    country: 'Portugal',
    description: 'Advanced underwater testing facility designed for comprehensive validation of marine robotics and autonomous underwater vehicles (AUVs).',
    functionalities: [
      'Wave generation system with programmable patterns',
      'Current simulation up to 2.5 knots',
      'Multi-beam sonar calibration suite',
      'Precision measurement and data acquisition systems',
      'High-speed underwater camera array',
      'Controlled lighting environment'
    ],
    capacityLimitations: 'Tank dimensions: 50m × 25m × 10m depth. Maximum vehicle size: 8m length. Weight capacity: 5000kg.',
    accessibility: 'Wheelchair accessible. Includes changing facilities, control room with climate control, and dedicated equipment storage.',
    availability: 'Quarterly scheduling available. Minimum 2-week advance booking required. Typical session: 3-5 days.',
    conditionsOfUse: 'Mandatory technical supervision. Safety briefing required. Insurance certificate needed for vehicles over 1000kg.',
    skillsTags: ['marine robotics', 'underwater testing', 'hydrodynamics', 'AUV testing', 'sonar calibration', 'vehicle dynamics'],
    photos: [
      'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=1200',
      'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=1200'
    ],
    technicalFiles: [
      { name: 'Technical Specifications.pdf', url: '#', type: 'application/pdf' },
      { name: 'Safety Protocols.pdf', url: '#', type: 'application/pdf' },
      { name: 'Equipment Manual.pdf', url: '#', type: 'application/pdf' }
    ],
    certificates: [
      { name: 'ISO 9001:2015', url: '#', type: 'certification' },
      { name: 'ISO 14001:2015', url: '#', type: 'certification' }
    ],
    externalApiId: 'AMRI-TANK-001',
    lastUpdated: '2026-01-05',
    featured: true
  },
  {
    id: 'asset-002',
    slug: 'autonomous-underwater-vehicle-fleet',
    name: 'Autonomous Underwater Vehicle (AUV) Fleet',
    assetType: 'infrastructure',
    subType: 'equipment',
    requiresTechnicalSupport: false,
    accessScope: 'hub-only',
    institution: 'Ocean Technology Center',
    city: 'Porto',
    country: 'Portugal',
    description: 'Fleet of 5 modular AUVs equipped with advanced sensors for oceanographic surveys and deep-sea research missions.',
    functionalities: [
      'Multi-beam sonar mapping',
      'CTD sensors for water analysis',
      '4K underwater cameras',
      'Side-scan sonar',
      'Magnetometer',
      'Sub-bottom profiler'
    ],
    capacityLimitations: 'Depth rating: 3000m. Endurance: 20 hours. Speed: 1-4 knots. Payload capacity: 50kg per vehicle.',
    accessibility: 'Training required for operation. Launch and recovery equipment available. Data processing workstation included.',
    availability: 'Available upon request with minimum 1-month advance notice. Deployment periods: 5-14 days typical.',
    conditionsOfUse: 'Operator certification required. Mission planning review mandatory. Weather window dependent.',
    skillsTags: ['marine robotics', 'oceanography', 'sonar mapping', 'deep-sea exploration', 'bathymetry', 'hydrography'],
    photos: [
      'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=1200',
      'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=1200'
    ],
    technicalFiles: [
      { name: 'AUV Specifications.pdf', url: '#', type: 'application/pdf' },
      { name: 'Operating Manual.pdf', url: '#', type: 'application/pdf' },
      { name: 'Mission Planning Guide.pdf', url: '#', type: 'application/pdf' }
    ],
    externalApiId: 'OTC-AUV-FLEET-01',
    lastUpdated: '2025-12-20'
  },
  {
    id: 'asset-003',
    slug: 'marine-biotechnology-laboratory',
    name: 'Marine Biotechnology Laboratory',
    assetType: 'infrastructure-with-support',
    subType: 'laboratory',
    requiresTechnicalSupport: true,
    accessScope: 'both',
    institution: 'Blue Biotech Research Hub',
    city: 'Faro',
    country: 'Portugal',
    description: 'State-of-the-art facility for marine organism cultivation, genetic analysis, and biochemical research.',
    functionalities: [
      'Flow cytometry',
      'Mass spectrometry',
      'DNA sequencing (Illumina platform)',
      'Protein purification systems',
      'Controlled cultivation chambers',
      'Cryogenic storage'
    ],
    capacityLimitations: 'Biosafety Level 2 certified. 12 workstations. Cold storage: 500L capacity. Sample processing: 100 samples/day.',
    accessibility: 'Full accessibility. PPE provided. Decontamination facilities. Emergency showers and eyewash stations.',
    availability: 'Monthly booking slots available. Minimum booking: 1 week. Maximum: 3 months per project.',
    conditionsOfUse: 'Biosafety training mandatory. Ethics approval required for certain organisms. Technical support included.',
    skillsTags: ['marine biotechnology', 'genetic analysis', 'aquaculture', 'bioprospecting', 'molecular biology', 'biochemistry'],
    photos: [
      'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=1200',
      'https://images.unsplash.com/photo-1576086213369-97a306d36557?w=1200'
    ],
    technicalFiles: [
      { name: 'Laboratory Manual.pdf', url: '#', type: 'application/pdf' },
      { name: 'Equipment List.pdf', url: '#', type: 'application/pdf' }
    ],
    certificates: [
      { name: 'GLP Certified', url: '#', type: 'certification' },
      { name: 'Biosafety Level 2', url: '#', type: 'certification' }
    ],
    externalApiId: 'BBRH-LAB-001',
    lastUpdated: '2026-01-03',
    featured: true
  },
  {
    id: 'asset-004',
    slug: 'oceanographic-data-analysis-platform',
    name: 'Oceanographic Data Analysis Platform',
    assetType: 'specific-service',
    subType: 'technical-support',
    requiresTechnicalSupport: true,
    accessScope: 'both',
    institution: 'Marine Data Science Institute',
    city: 'Lisboa',
    country: 'Portugal',
    description: 'Cloud-based platform with advanced tools for processing satellite imagery, oceanographic data, and AI-powered predictive models.',
    functionalities: [
      'Satellite imagery processing',
      'Machine learning model training',
      'Oceanographic data visualization',
      'Climate modeling',
      'Big data analytics',
      'API access for integration'
    ],
    serviceMethodology: 'Collaborative approach with dedicated data scientist support. Custom workflow development. Training sessions included.',
    serviceDeliveryTime: '2-4 weeks for initial setup. Ongoing support available 24/7.',
    serviceCustomization: 'Fully customizable workflows. Can integrate with existing systems. Custom model development available.',
    capacityLimitations: 'Computational resources: 100 CPU cores, 500GB RAM, 10TB storage per project. Concurrent users: up to 20.',
    accessibility: 'Remote access via web portal. VPN available for secure data transfer. Multi-language support.',
    availability: 'Continuous access, 24/7 technical support. Onboarding: 1 week notice required.',
    conditionsOfUse: 'Data sharing agreement required. Attribution for publications. Service level agreement (SLA) included.',
    skillsTags: ['data analysis', 'remote sensing', 'machine learning', 'climate modeling', 'oceanography', 'satellite imagery'],
    photos: [
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200',
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200'
    ],
    technicalFiles: [
      { name: 'API Documentation.pdf', url: '#', type: 'application/pdf' },
      { name: 'User Guide.pdf', url: '#', type: 'application/pdf' },
      { name: 'Platform Architecture.pdf', url: '#', type: 'application/pdf' }
    ],
    externalApiId: 'MDSI-PLATFORM-01',
    lastUpdated: '2025-12-28'
  },
  {
    id: 'asset-005',
    slug: 'wave-energy-testing-flume',
    name: 'Wave Energy Testing Flume',
    assetType: 'infrastructure-with-support',
    subType: 'laboratory',
    requiresTechnicalSupport: true,
    accessScope: 'both',
    institution: 'Renewable Ocean Energy Lab',
    city: 'Viana do Castelo',
    country: 'Portugal',
    description: '120-meter wave flume facility for testing wave energy converters, offshore structures, and coastal engineering models.',
    functionalities: [
      'Variable wave generation (0.1-2m height)',
      'Current generation system',
      'Precision force measurement',
      'High-speed video capture',
      'Data acquisition at 1kHz',
      'Model fabrication workshop'
    ],
    capacityLimitations: 'Flume: 120m × 4m × 3m depth. Wave period: 0.5-5 seconds. Model scale: 1:10 to 1:100 typical.',
    accessibility: 'Ground floor access. Overhead crane for model deployment. Control room with viewing gallery.',
    availability: 'Quarterly scheduling available. Sessions: 1-3 weeks typical. Advance booking: 3 months recommended.',
    conditionsOfUse: 'Technical supervision mandatory. Safety training required. Model pre-approval needed.',
    skillsTags: ['wave energy', 'coastal engineering', 'renewable energy', 'offshore structures', 'hydraulic testing', 'model testing'],
    photos: [
      'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=1200',
      'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=1200'
    ],
    technicalFiles: [
      { name: 'Facility Specifications.pdf', url: '#', type: 'application/pdf' },
      { name: 'Safety Guidelines.pdf', url: '#', type: 'application/pdf' }
    ],
    certificates: [
      { name: 'ISO 17025:2017', url: '#', type: 'certification' }
    ],
    externalApiId: 'ROEL-FLUME-001',
    lastUpdated: '2026-01-02',
    featured: true
  },
  {
    id: 'asset-006',
    slug: 'underwater-rov-system',
    name: 'Underwater ROV System',
    assetType: 'infrastructure',
    subType: 'equipment',
    requiresTechnicalSupport: false,
    accessScope: 'external',
    institution: 'Coastal Research Station',
    city: 'Setúbal',
    country: 'Portugal',
    description: 'Professional-grade remotely operated vehicle with 4K video, manipulator arm, and sonar. Ideal for inspection, sampling, and documentation.',
    functionalities: [
      '4K video recording',
      '5-function manipulator arm',
      'Forward-looking sonar',
      'LED lighting array',
      'Sampling basket',
      'Auto-depth and auto-heading'
    ],
    capacityLimitations: 'Maximum depth: 500m. Tether length: 600m. Payload capacity: 20kg. Operating time: 8 hours.',
    accessibility: 'Portable system. Launch from vessel or shore. Training provided. Data storage included.',
    availability: 'Available upon request. Minimum rental: 3 days. Transportation included within Portugal.',
    conditionsOfUse: 'Pilot certification recommended but not required. Insurance required. Weather dependent.',
    skillsTags: ['underwater inspection', 'marine robotics', 'video documentation', 'sampling', 'subsea operations'],
    photos: [
      'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=1200'
    ],
    technicalFiles: [
      { name: 'ROV Specifications.pdf', url: '#', type: 'application/pdf' },
      { name: 'Operating Manual.pdf', url: '#', type: 'application/pdf' }
    ],
    externalApiId: 'CRS-ROV-001',
    lastUpdated: '2025-12-15'
  },
  {
    id: 'asset-007',
    slug: 'marine-engineering-consulting',
    name: 'Marine Engineering Consulting',
    assetType: 'specific-service',
    subType: 'consulting',
    requiresTechnicalSupport: true,
    accessScope: 'both',
    institution: 'Maritime Engineering Group',
    city: 'Porto',
    country: 'Portugal',
    description: 'Expert consulting services for marine infrastructure projects, offshore platform design, and subsea engineering.',
    functionalities: [
      'Structural analysis',
      'Hydrodynamic modeling',
      'Risk assessment',
      'Regulatory compliance review',
      'Project management',
      'Technical documentation'
    ],
    serviceMethodology: 'Dedicated team assignment. Regular progress meetings. Deliverable-based milestones. Quality assurance review.',
    serviceDeliveryTime: 'Initial assessment: 2 weeks. Full project: 2-6 months depending on scope. Rush services available.',
    serviceCustomization: 'Fully tailored to project requirements. Can work with existing designs. Multi-disciplinary team available.',
    capacityLimitations: 'Team size: 15+ engineers. Concurrent projects: up to 10. Languages: Portuguese, English, Spanish.',
    accessibility: 'Remote and on-site meetings available. Digital deliverables. Secure file sharing portal.',
    availability: 'By appointment, flexible scheduling. Initial consultation: 1 week notice.',
    conditionsOfUse: 'NDA required. Statement of work agreement. Progress payment terms.',
    skillsTags: ['marine engineering', 'offshore structures', 'subsea systems', 'project management', 'structural analysis', 'hydrodynamics'],
    photos: [
      'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1200',
      'https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?w=1200'
    ],
    technicalFiles: [
      { name: 'Service Portfolio.pdf', url: '#', type: 'application/pdf' },
      { name: 'Case Studies.pdf', url: '#', type: 'application/pdf' }
    ],
    certificates: [
      { name: 'Professional Engineering License', url: '#', type: 'certification' }
    ],
    externalApiId: 'MEG-CONSULT-01',
    lastUpdated: '2025-12-10'
  },
  {
    id: 'asset-008',
    slug: 'aquaculture-research-facility',
    name: 'Aquaculture Research Facility',
    assetType: 'infrastructure-with-support',
    subType: 'laboratory',
    requiresTechnicalSupport: true,
    accessScope: 'hub-only',
    institution: 'Sustainable Aquaculture Institute',
    city: 'Olhão',
    country: 'Portugal',
    description: 'Comprehensive aquaculture facility with indoor and outdoor tanks for fish and shellfish cultivation research.',
    functionalities: [
      'Recirculating aquaculture systems (RAS)',
      'Water quality monitoring',
      'Automated feeding systems',
      'Disease diagnostics',
      'Breeding facilities',
      'Growth analysis equipment'
    ],
    capacityLimitations: '50+ tanks (50L to 5000L). Species capacity: 20 different species concurrently. Water treatment: 100m³/day.',
    accessibility: 'Biosecurity protocols mandatory. Quarantine facilities available. Staff support 5 days/week.',
    availability: 'Quarterly scheduling, minimum 3-month project duration. Year-round availability.',
    conditionsOfUse: 'Biosecurity clearance required. Species approval needed. Technical supervision included.',
    skillsTags: ['aquaculture', 'fish farming', 'water quality', 'marine biology', 'breeding', 'sustainability'],
    photos: [
      'https://images.unsplash.com/photo-1535591273668-578e31182c4f?w=1200',
      'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=1200'
    ],
    technicalFiles: [
      { name: 'Facility Guide.pdf', url: '#', type: 'application/pdf' },
      { name: 'Biosecurity Protocols.pdf', url: '#', type: 'application/pdf' }
    ],
    certificates: [
      { name: 'Aquaculture Certification', url: '#', type: 'certification' }
    ],
    externalApiId: 'SAI-FACILITY-01',
    lastUpdated: '2025-12-18'
  }
];

// Extract unique values for filters
export const getUniqueInstitutions = (): string[] => {
  return Array.from(new Set(cmsAssets.map(asset => asset.institution))).sort();
};

export const getUniqueCities = (): string[] => {
  return Array.from(new Set(cmsAssets.map(asset => asset.city))).sort();
};

export const getAllSkillsTags = (): string[] => {
  const allTags = cmsAssets.flatMap(asset => asset.skillsTags);
  return Array.from(new Set(allTags)).sort();
};
