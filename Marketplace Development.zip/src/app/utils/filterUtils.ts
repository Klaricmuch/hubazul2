import { FilterState, Asset } from '../types/cms-schema';

export const parseFiltersFromUrl = (searchParams: URLSearchParams): FilterState => {
  return {
    assetType: searchParams.get('assetType')?.split(',').filter(Boolean) || [],
    subType: searchParams.get('subType')?.split(',').filter(Boolean) || [],
    institution: searchParams.get('institution')?.split(',').filter(Boolean) || [],
    city: searchParams.get('city')?.split(',').filter(Boolean) || [],
    skillsTags: searchParams.get('skills')?.split(',').filter(Boolean) || [],
    requiresTechnicalSupport: searchParams.get('technicalSupport') === 'yes' ? true : searchParams.get('technicalSupport') === 'no' ? false : null,
    accessScope: searchParams.get('accessScope')?.split(',').filter(Boolean) || [],
    search: searchParams.get('q') || ''
  };
};

export const filtersToUrlParams = (filters: FilterState): string => {
  const params = new URLSearchParams();
  
  if (filters.assetType.length > 0) params.set('assetType', filters.assetType.join(','));
  if (filters.subType.length > 0) params.set('subType', filters.subType.join(','));
  if (filters.institution.length > 0) params.set('institution', filters.institution.join(','));
  if (filters.city.length > 0) params.set('city', filters.city.join(','));
  if (filters.skillsTags.length > 0) params.set('skills', filters.skillsTags.join(','));
  if (filters.requiresTechnicalSupport !== null) {
    params.set('technicalSupport', filters.requiresTechnicalSupport ? 'yes' : 'no');
  }
  if (filters.accessScope.length > 0) params.set('accessScope', filters.accessScope.join(','));
  if (filters.search) params.set('q', filters.search);
  
  return params.toString();
};

export const applyFilters = (assets: Asset[], filters: FilterState): Asset[] => {
  return assets.filter(asset => {
    // Search query
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      const matchesSearch = 
        asset.name.toLowerCase().includes(searchLower) ||
        asset.description.toLowerCase().includes(searchLower) ||
        asset.institution.toLowerCase().includes(searchLower) ||
        asset.city.toLowerCase().includes(searchLower) ||
        asset.skillsTags.some(tag => tag.toLowerCase().includes(searchLower));
      
      if (!matchesSearch) return false;
    }
    
    // Asset type filter
    if (filters.assetType.length > 0 && !filters.assetType.includes(asset.assetType)) {
      return false;
    }
    
    // Sub type filter
    if (filters.subType.length > 0 && !filters.subType.includes(asset.subType)) {
      return false;
    }
    
    // Institution filter
    if (filters.institution.length > 0 && !filters.institution.includes(asset.institution)) {
      return false;
    }
    
    // City filter
    if (filters.city.length > 0 && !filters.city.includes(asset.city)) {
      return false;
    }
    
    // Skills tags filter (asset must have at least one of the selected tags)
    if (filters.skillsTags.length > 0) {
      const hasMatchingTag = filters.skillsTags.some(tag => 
        asset.skillsTags.includes(tag)
      );
      if (!hasMatchingTag) return false;
    }
    
    // Technical support filter
    if (filters.requiresTechnicalSupport !== null && 
        asset.requiresTechnicalSupport !== filters.requiresTechnicalSupport) {
      return false;
    }
    
    // Access scope filter
    if (filters.accessScope.length > 0) {
      const matchesScope = filters.accessScope.includes(asset.accessScope) ||
        (filters.accessScope.includes('both') && asset.accessScope === 'both');
      if (!matchesScope) return false;
    }
    
    return true;
  });
};

export const getActiveFilterCount = (filters: FilterState): number => {
  let count = 0;
  if (filters.assetType.length > 0) count += filters.assetType.length;
  if (filters.subType.length > 0) count += filters.subType.length;
  if (filters.institution.length > 0) count += filters.institution.length;
  if (filters.city.length > 0) count += filters.city.length;
  if (filters.skillsTags.length > 0) count += filters.skillsTags.length;
  if (filters.requiresTechnicalSupport !== null) count += 1;
  if (filters.accessScope.length > 0) count += filters.accessScope.length;
  if (filters.search) count += 1;
  return count;
};
