import React from 'react';
import { MapPin, Tag, Star, CheckCircle, XCircle, CreditCard } from 'lucide-react';
import { Asset } from '../types/cms-schema';

interface AssetGridProps {
  assets: Asset[];
  onAssetClick: (slug: string) => void;
}

export function AssetGrid({ assets, onAssetClick }: AssetGridProps) {
  // Sort: featured first, then by last updated
  const sortedAssets = [...assets].sort((a, b) => {
    if (a.featured && !b.featured) return -1;
    if (!a.featured && b.featured) return 1;
    return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
  });

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {sortedAssets.map((asset) => (
        <AssetCard key={asset.id} asset={asset} onClick={() => onAssetClick(asset.slug)} />
      ))}
    </div>
  );
}

function AssetCard({ asset, onClick }: { asset: Asset; onClick: () => void }) {
  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      'infrastructure': 'Infrastructure',
      'infrastructure-with-support': 'Infrastructure + Support',
      'specific-service': 'Service',
      'equipment': 'Equipment',
      'laboratory': 'Laboratory',
      'technical-support': 'Technical Support',
      'consulting': 'Consulting',
      'analysis': 'Analysis'
    };
    return labels[type] || type;
  };

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      'infrastructure': 'bg-[#00A9A5] text-white',
      'infrastructure-with-support': 'bg-[#1E3A8A] text-white',
      'specific-service': 'bg-green-600 text-white',
      'equipment': 'bg-blue-600 text-white',
      'laboratory': 'bg-purple-600 text-white'
    };
    return colors[type] || 'bg-gray-600 text-white';
  };

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-xl hover:border-[#00A9A5] transition-all cursor-pointer group"
    >
      {/* Image */}
      <div className="relative h-48 bg-gray-200 overflow-hidden">
        <img
          src={asset.photos[0]}
          alt={asset.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-3 left-3 flex gap-2">
          <span className={`px-3 py-1.5 rounded-md text-xs font-semibold shadow-md ${getTypeColor(asset.assetType)}`}>
            {getTypeLabel(asset.assetType)}
          </span>
          {asset.featured && (
            <span className="px-3 py-1.5 rounded-md text-xs font-semibold bg-yellow-400 text-yellow-900 shadow-md flex items-center gap-1">
              <Star className="w-3 h-3 fill-current" />
              Featured
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <h3 className="font-bold text-xl mb-3 line-clamp-2 text-[#1E3A8A] group-hover:text-[#00A9A5] transition-colors">
          {asset.name}
        </h3>
        
        <p className="text-sm text-gray-600 mb-4 line-clamp-3 leading-relaxed">
          {asset.description}
        </p>

        {/* Location */}
        <div className="flex items-start gap-3 mb-4 pb-4 border-b border-gray-100">
          <MapPin className="w-5 h-5 text-[#00A9A5] mt-0.5 flex-shrink-0" />
          <div className="text-sm min-w-0">
            <div className="font-semibold text-[#1E3A8A] mb-0.5">{asset.institution}</div>
            <div className="text-gray-600">{asset.city}</div>
          </div>
        </div>

        {/* Skills Tags */}
        {asset.skillsTags.length > 0 && (
          <div className="flex items-start gap-3 mb-4">
            <Tag className="w-5 h-5 text-[#00A9A5] mt-0.5 flex-shrink-0" />
            <div className="flex flex-wrap gap-2 min-w-0">
              {asset.skillsTags.slice(0, 3).map((skill, index) => (
                <span
                  key={index}
                  className="px-2.5 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded"
                >
                  {skill}
                </span>
              ))}
              {asset.skillsTags.length > 3 && (
                <span className="px-2.5 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded">
                  +{asset.skillsTags.length - 3} more
                </span>
              )}
            </div>
          </div>
        )}

        {/* Footer Info */}
        <div className="flex items-center justify-between text-sm pt-4 border-t border-gray-100 mb-4">
          <div className="flex items-center gap-2">
            {asset.requiresTechnicalSupport ? (
              <>
                <CheckCircle className="w-4 h-4 text-[#00A9A5]" />
                <span className="text-[#00A9A5] font-medium">Support</span>
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 text-gray-400" />
                <span className="text-gray-500">No Support</span>
              </>
            )}
          </div>
          
          <span className="text-gray-500 text-xs font-medium capitalize">{asset.accessScope.replace('-', ' ')}</span>
        </div>

        {/* Book Now Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onClick();
          }}
          className="w-full bg-[#00A9A5] hover:bg-[#008A87] text-white font-semibold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 group/btn"
        >
          <CreditCard className="w-4 h-4" />
          <span>Request Booking</span>
        </button>
      </div>
    </div>
  );
}