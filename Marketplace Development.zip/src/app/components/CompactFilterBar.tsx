import React, { useState, useRef, useEffect } from 'react';
import { Search, ChevronDown, SlidersHorizontal } from 'lucide-react';
import { FilterState } from '../types/cms-schema';

interface CompactFilterBarProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  institutions: string[];
  cities: string[];
  skillsTags: string[];
}

export function CompactFilterBar({
  filters,
  onFilterChange,
  institutions,
  cities,
  skillsTags
}: CompactFilterBarProps) {
  const [searchExpanded, setSearchExpanded] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);

  return (
    <div className="mb-6">
      {/* Single Row with Search and Filters */}
      <div className="flex flex-wrap gap-2 items-center">
        {/* Expandable Search Bar */}
        <div className={`relative transition-all duration-300 ${
          searchExpanded ? 'w-full order-first' : 'w-64'
        }`}>
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            ref={searchRef}
            type="text"
            placeholder="Search assets, services, locations, or skills..."
            value={filters.search}
            onChange={(e) => onFilterChange({ ...filters, search: e.target.value })}
            onFocus={() => setSearchExpanded(true)}
            onBlur={() => {
              if (!filters.search) {
                setSearchExpanded(false);
              }
            }}
            className="w-full pl-10 pr-4 py-2.5 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A9A5] focus:border-transparent"
          />
        </div>

        {/* Filter Dropdowns - Only show when search is not expanded */}
        {!searchExpanded && (
          <>
            <FilterDropdown
              label="Type"
              options={[
                { value: 'infrastructure', label: 'Infrastructure' },
                { value: 'infrastructure-with-support', label: 'Infrastructure + Support' },
                { value: 'specific-service', label: 'Services' }
              ]}
              selected={filters.assetType}
              onChange={(value) => {
                const newArray = filters.assetType.includes(value)
                  ? filters.assetType.filter(v => v !== value)
                  : [...filters.assetType, value];
                onFilterChange({ ...filters, assetType: newArray });
              }}
            />

            <FilterDropdown
              label="Category"
              options={[
                { value: 'equipment', label: 'Equipment' },
                { value: 'laboratory', label: 'Laboratory' },
                { value: 'technical-support', label: 'Technical Support' },
                { value: 'consulting', label: 'Consulting' },
                { value: 'analysis', label: 'Analysis' }
              ]}
              selected={filters.subType}
              onChange={(value) => {
                const newArray = filters.subType.includes(value)
                  ? filters.subType.filter(v => v !== value)
                  : [...filters.subType, value];
                onFilterChange({ ...filters, subType: newArray });
              }}
            />

            <FilterDropdown
              label="Institution"
              options={institutions.map(inst => ({ value: inst, label: inst }))}
              selected={filters.institution}
              onChange={(value) => {
                const newArray = filters.institution.includes(value)
                  ? filters.institution.filter(v => v !== value)
                  : [...filters.institution, value];
                onFilterChange({ ...filters, institution: newArray });
              }}
            />

            <FilterDropdown
              label="City"
              options={cities.map(city => ({ value: city, label: city }))}
              selected={filters.city}
              onChange={(value) => {
                const newArray = filters.city.includes(value)
                  ? filters.city.filter(v => v !== value)
                  : [...filters.city, value];
                onFilterChange({ ...filters, city: newArray });
              }}
            />

            <FilterDropdown
              label="Skills"
              options={skillsTags.map(tag => ({ value: tag, label: tag }))}
              selected={filters.skillsTags}
              onChange={(value) => {
                const newArray = filters.skillsTags.includes(value)
                  ? filters.skillsTags.filter(v => v !== value)
                  : [...filters.skillsTags, value];
                onFilterChange({ ...filters, skillsTags: newArray });
              }}
              maxHeight="max-h-64"
            />

            <FilterDropdown
              label="Access"
              options={[
                { value: 'hub-only', label: 'Hub Azul Only' },
                { value: 'external', label: 'External Users' },
                { value: 'both', label: 'Both' }
              ]}
              selected={filters.accessScope}
              onChange={(value) => {
                const newArray = filters.accessScope.includes(value)
                  ? filters.accessScope.filter(v => v !== value)
                  : [...filters.accessScope, value];
                onFilterChange({ ...filters, accessScope: newArray });
              }}
            />

            <SingleSelectDropdown
              label="Support"
              value={filters.requiresTechnicalSupport}
              options={[
                { value: null, label: 'All' },
                { value: true, label: 'With' },
                { value: false, label: 'Without' }
              ]}
              onChange={(value) => onFilterChange({ ...filters, requiresTechnicalSupport: value })}
            />
          </>
        )}
      </div>
    </div>
  );
}

interface FilterDropdownProps {
  label: string;
  options: { value: string; label: string }[];
  selected: string[];
  onChange: (value: string) => void;
  maxHeight?: string;
}

function FilterDropdown({ label, options, selected, onChange, maxHeight = 'max-h-48' }: FilterDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={dropdownRef} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`px-4 py-2.5 border rounded-lg flex items-center gap-2 text-sm font-medium transition-colors ${
          selected.length > 0
            ? 'bg-[#00A9A5] text-white border-[#00A9A5]'
            : 'bg-white text-gray-700 border-gray-300 hover:border-[#00A9A5]'
        }`}
      >
        <SlidersHorizontal className="w-4 h-4" />
        <span>{label}</span>
        {selected.length > 0 && (
          <span className={`px-1.5 py-0.5 rounded-full text-xs font-semibold ${
            selected.length > 0 ? 'bg-white text-[#00A9A5]' : 'bg-[#00A9A5] text-white'
          }`}>
            {selected.length}
          </span>
        )}
        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className={`absolute top-full left-0 mt-2 w-64 bg-white border border-gray-200 rounded-lg shadow-lg z-50 overflow-hidden`}>
          <div className={`overflow-y-auto ${maxHeight} p-2`}>
            {options.map(option => (
              <label
                key={option.value}
                className="flex items-center gap-2 px-3 py-2 hover:bg-gray-50 rounded cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selected.includes(option.value)}
                  onChange={() => onChange(option.value)}
                  className="w-4 h-4 text-[#00A9A5] rounded border-gray-300 focus:ring-[#00A9A5]"
                />
                <span className="text-sm text-gray-700">{option.label}</span>
              </label>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

interface SingleSelectDropdownProps {
  label: string;
  options: { value: boolean | null; label: string }[];
  value: boolean | null;
  onChange: (value: boolean | null) => void;
}

function SingleSelectDropdown({ label, options, value, onChange }: SingleSelectDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedLabel = options.find(opt => opt.value === value)?.label || 'All';

  return (
    <div ref={dropdownRef} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`px-4 py-2.5 border rounded-lg flex items-center gap-2 text-sm font-medium transition-colors ${
          value !== null
            ? 'bg-[#00A9A5] text-white border-[#00A9A5]'
            : 'bg-white text-gray-700 border-gray-300 hover:border-[#00A9A5]'
        }`}
      >
        <SlidersHorizontal className="w-4 h-4" />
        <span>{label}: {selectedLabel}</span>
        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-56 bg-white border border-gray-200 rounded-lg shadow-lg z-50 overflow-hidden">
          <div className="p-2">
            {options.map((option, index) => (
              <button
                key={index}
                onClick={() => {
                  onChange(option.value);
                  setIsOpen(false);
                }}
                className={`w-full text-left px-3 py-2 hover:bg-gray-50 rounded text-sm ${
                  value === option.value ? 'bg-[#00A9A5]/10 text-[#00A9A5] font-medium' : 'text-gray-700'
                }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}