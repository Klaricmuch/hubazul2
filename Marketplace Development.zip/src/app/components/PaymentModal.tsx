import React, { useState } from 'react';
import { X, CreditCard, Lock, Calendar, Clock, MapPin, CheckCircle, Building2, Wallet } from 'lucide-react';
import { Asset } from '../types/cms-schema';

type PaymentMethod = 'credit-card' | 'paypal' | 'bank-transfer' | 'mbway';

interface PaymentModalProps {
  asset: Asset;
  selectedDate: Date;
  selectedTime: string;
  onClose: () => void;
  onConfirm: () => void;
}

export function PaymentModal({ asset, selectedDate, selectedTime, onClose, onConfirm }: PaymentModalProps) {
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('credit-card');

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    if (v.length >= 2) {
      return v.slice(0, 2) + '/' + v.slice(2, 4);
    }
    return v;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    setProcessing(false);
    setSuccess(true);

    // Close modal and confirm after showing success
    setTimeout(() => {
      onConfirm();
      onClose();
    }, 2000);
  };

  if (success) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Booking Confirmed!</h3>
          <p className="text-gray-600 mb-4">
            Your booking has been successfully processed. You will receive a confirmation email shortly.
          </p>
          <div className="bg-gray-50 rounded-lg p-4 text-left">
            <div className="text-sm space-y-2">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#00A9A5]" />
                <span>{selectedDate.toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#00A9A5]" />
                <span>{selectedTime}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-lg max-w-2xl w-full my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-[#1E3A8A]">Complete Your Booking</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Booking Summary */}
          <div className="bg-gradient-to-br from-[#00A9A5]/10 to-blue-50 border border-[#00A9A5]/30 rounded-lg p-6 mb-6">
            <h3 className="font-semibold text-[#1E3A8A] mb-4">Booking Summary</h3>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-600 mb-1">Asset</p>
                <p className="font-semibold text-[#1E3A8A]">{asset.name}</p>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#00A9A5] mt-0.5 flex-shrink-0" />
                <div className="text-sm">
                  <p className="font-medium text-[#1E3A8A]">{asset.institution}</p>
                  <p className="text-gray-600">{asset.city}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#00A9A5]" />
                <span className="text-sm font-medium text-[#1E3A8A]">
                  {selectedDate.toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#00A9A5]" />
                <span className="text-sm font-medium text-[#1E3A8A]">{selectedTime}</span>
              </div>
              <div className="pt-3 border-t border-[#00A9A5]/30 mt-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Total Amount</span>
                  <span className="text-2xl font-bold text-[#1E3A8A]">€250.00</span>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Payment Method Selection */}
            <div>
              <h3 className="font-semibold text-[#1E3A8A] mb-4">Select Payment Method</h3>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('credit-card')}
                  className={`p-4 border-2 rounded-lg transition-all flex flex-col items-center gap-2 ${
                    paymentMethod === 'credit-card'
                      ? 'border-[#00A9A5] bg-[#00A9A5]/5'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <CreditCard className={`w-6 h-6 ${paymentMethod === 'credit-card' ? 'text-[#00A9A5]' : 'text-gray-400'}`} />
                  <span className={`text-sm font-medium ${paymentMethod === 'credit-card' ? 'text-[#00A9A5]' : 'text-gray-700'}`}>
                    Credit Card
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('paypal')}
                  className={`p-4 border-2 rounded-lg transition-all flex flex-col items-center gap-2 ${
                    paymentMethod === 'paypal'
                      ? 'border-[#00A9A5] bg-[#00A9A5]/5'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Wallet className={`w-6 h-6 ${paymentMethod === 'paypal' ? 'text-[#00A9A5]' : 'text-gray-400'}`} />
                  <span className={`text-sm font-medium ${paymentMethod === 'paypal' ? 'text-[#00A9A5]' : 'text-gray-700'}`}>
                    PayPal
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank-transfer')}
                  className={`p-4 border-2 rounded-lg transition-all flex flex-col items-center gap-2 ${
                    paymentMethod === 'bank-transfer'
                      ? 'border-[#00A9A5] bg-[#00A9A5]/5'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <Building2 className={`w-6 h-6 ${paymentMethod === 'bank-transfer' ? 'text-[#00A9A5]' : 'text-gray-400'}`} />
                  <span className={`text-sm font-medium ${paymentMethod === 'bank-transfer' ? 'text-[#00A9A5]' : 'text-gray-700'}`}>
                    Bank Transfer
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('mbway')}
                  className={`p-4 border-2 rounded-lg transition-all flex flex-col items-center gap-2 ${
                    paymentMethod === 'mbway'
                      ? 'border-[#00A9A5] bg-[#00A9A5]/5'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className={`text-xl font-bold ${paymentMethod === 'mbway' ? 'text-[#00A9A5]' : 'text-gray-400'}`}>
                    MB
                  </div>
                  <span className={`text-sm font-medium ${paymentMethod === 'mbway' ? 'text-[#00A9A5]' : 'text-gray-700'}`}>
                    MB WAY
                  </span>
                </button>
              </div>
            </div>

            {/* Payment Details based on selected method */}
            {paymentMethod === 'credit-card' && (
              <div>
                <h3 className="font-semibold text-[#1E3A8A] mb-4 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-[#00A9A5]" />
                  Card Details
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Card Number
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                      placeholder="1234 5678 9012 3456"
                      maxLength={19}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A9A5] focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Cardholder Name
                    </label>
                    <input
                      type="text"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      placeholder="John Doe"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A9A5] focus:border-transparent"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Expiry Date
                      </label>
                      <input
                        type="text"
                        value={expiry}
                        onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                        placeholder="MM/YY"
                        maxLength={5}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A9A5] focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        CVV
                      </label>
                      <input
                        type="text"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
                        placeholder="123"
                        maxLength={3}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A9A5] focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {paymentMethod === 'paypal' && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Wallet className="w-6 h-6 text-blue-600" />
                  <h3 className="font-semibold text-[#1E3A8A]">PayPal Payment</h3>
                </div>
                <p className="text-sm text-gray-700 mb-4">
                  You will be redirected to PayPal to complete your payment securely.
                </p>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Lock className="w-4 h-4" />
                  <span>Secured by PayPal</span>
                </div>
              </div>
            )}

            {paymentMethod === 'bank-transfer' && (
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Building2 className="w-6 h-6 text-[#00A9A5]" />
                  <h3 className="font-semibold text-[#1E3A8A]">Bank Transfer Details</h3>
                </div>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="text-gray-600 mb-1">Bank Name</p>
                    <p className="font-medium text-[#1E3A8A]">Banco de Portugal</p>
                  </div>
                  <div>
                    <p className="text-gray-600 mb-1">IBAN</p>
                    <p className="font-mono text-[#1E3A8A]">PT50 0000 0000 0000 0000 0000 0</p>
                  </div>
                  <div>
                    <p className="text-gray-600 mb-1">Reference</p>
                    <p className="font-mono text-[#1E3A8A]">HUBAUL{Math.floor(Math.random() * 100000)}</p>
                  </div>
                  <div className="bg-yellow-50 border border-yellow-200 rounded p-3 mt-4">
                    <p className="text-xs text-yellow-800">
                      ⚠️ Please include the reference number in your transfer. Your booking will be confirmed once payment is received (1-3 business days).
                    </p>
                  </div>
                </div>
              </div>
            )}

            {paymentMethod === 'mbway' && (
              <div className="bg-gradient-to-br from-red-50 to-orange-50 border border-red-200 rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="text-2xl font-bold text-red-600">MB</div>
                  <h3 className="font-semibold text-[#1E3A8A]">MB WAY Payment</h3>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      placeholder="+351 900 000 000"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#00A9A5] focus:border-transparent"
                    />
                  </div>
                  <p className="text-xs text-gray-600">
                    You will receive a notification on your MB WAY app to approve this payment.
                  </p>
                </div>
              </div>
            )}

            {/* Security Notice */}
            <div className="bg-gray-50 rounded-lg p-4 flex items-start gap-3">
              <Lock className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-gray-700">
                <p className="font-medium text-gray-900 mb-1">Secure Payment</p>
                <p>Your payment information is encrypted and secure. We never store your full card details.</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={processing}
                className="flex-1 px-6 py-3 bg-[#00A9A5] text-white font-medium rounded-lg hover:bg-[#008F8C] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {processing ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-5 h-5" />
                    <span>Pay €250.00</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}