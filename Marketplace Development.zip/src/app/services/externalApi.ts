import { ExternalApiResponse } from '../types/cms-schema';

/**
 * External API Integration
 * 
 * This service integrates with an external API to fetch real-time asset metadata.
 * In production, this would connect to Hub Azul's asset management system.
 * 
 * For demonstration, we use the Open-Meteo API for ocean/weather data as a placeholder.
 */

const API_CACHE: Map<string, { data: ExternalApiResponse; timestamp: number }> = new Map();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Mock external API responses for demonstration
const MOCK_API_RESPONSES: Record<string, ExternalApiResponse> = {
  'AMRI-TANK-001': {
    assetId: 'AMRI-TANK-001',
    liveAvailability: 'available',
    lastCalibrationDate: '2025-12-15',
    nextMaintenanceDate: '2026-03-01',
    ownerContact: 'facilities@amri.pt',
    realTimeMetadata: {
      waterTemperature: '18°C',
      currentStatus: 'Operational',
      lastUsed: '2025-12-20'
    }
  },
  'OTC-AUV-FLEET-01': {
    assetId: 'OTC-AUV-FLEET-01',
    liveAvailability: 'booked',
    lastCalibrationDate: '2025-11-30',
    nextMaintenanceDate: '2026-02-15',
    ownerContact: 'auv-fleet@otc.pt',
    realTimeMetadata: {
      vehiclesAvailable: '2 of 5',
      currentDeployment: 'Atlantic Survey Mission',
      returnDate: '2026-01-25'
    }
  },
  'BBRH-LAB-001': {
    assetId: 'BBRH-LAB-001',
    liveAvailability: 'available',
    lastCalibrationDate: '2026-01-02',
    nextMaintenanceDate: '2026-04-01',
    ownerContact: 'lab@bluebiotech.pt',
    realTimeMetadata: {
      currentProjects: '3 active',
      availableWorkstations: '7 of 12',
      nextAvailableSlot: '2026-02-15'
    }
  }
};

export const fetchExternalAssetData = async (
  externalApiId: string
): Promise<ExternalApiResponse | null> => {
  try {
    // Check cache first
    const cached = API_CACHE.get(externalApiId);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      console.log(`[API] Cache hit for ${externalApiId}`);
      return cached.data;
    }

    console.log(`[API] Fetching data for ${externalApiId}`);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
    
    // In production, this would be a real API call:
    // const response = await fetch(`https://api.hubazul.pt/assets/${externalApiId}`);
    // const data = await response.json();
    
    // For demonstration, use mock data
    const data = MOCK_API_RESPONSES[externalApiId] || {
      assetId: externalApiId,
      liveAvailability: 'available',
      realTimeMetadata: {
        status: 'Data not available'
      }
    };
    
    // Cache the response
    API_CACHE.set(externalApiId, {
      data,
      timestamp: Date.now()
    });
    
    return data;
  } catch (error) {
    console.error(`[API] Error fetching data for ${externalApiId}:`, error);
    return null;
  }
};

export const getAvailabilityBadgeColor = (
  availability?: 'available' | 'booked' | 'maintenance'
): string => {
  switch (availability) {
    case 'available':
      return 'bg-green-100 text-green-800 border-green-300';
    case 'booked':
      return 'bg-orange-100 text-orange-800 border-orange-300';
    case 'maintenance':
      return 'bg-red-100 text-red-800 border-red-300';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-300';
  }
};

export const getAvailabilityLabel = (
  availability?: 'available' | 'booked' | 'maintenance'
): string => {
  switch (availability) {
    case 'available':
      return 'Available Now';
    case 'booked':
      return 'Currently Booked';
    case 'maintenance':
      return 'Under Maintenance';
    default:
      return 'Status Unknown';
  }
};
