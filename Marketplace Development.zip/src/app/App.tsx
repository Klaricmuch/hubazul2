import React, { useState, useEffect } from 'react';
import { Search as SearchIcon, Menu, X } from 'lucide-react';
import { MarketplaceCatalog } from './pages/MarketplaceCatalog';
import { AssetDetailPage } from './pages/AssetDetailPage';
import { cmsAssets } from './data/cms-assets';
import logoImage from 'figma:asset/91a2d327cd8e775e6548c5677f7f45058bda535c.png';

type Route = 
  | { page: 'catalog' }
  | { page: 'asset'; slug: string };

function App() {
  const [route, setRoute] = useState<Route>({ page: 'catalog' });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  useEffect(() => {
    const hash = window.location.hash;
    
    if (hash.startsWith('#/rd-asset-marketplace/assets/')) {
      const slug = hash.replace('#/rd-asset-marketplace/assets/', '');
      setRoute({ page: 'asset', slug });
    } else {
      setRoute({ page: 'catalog' });
    }
  }, []);
  
  const navigateToAsset = (slug: string) => {
    window.location.hash = `/rd-asset-marketplace/assets/${slug}`;
    setRoute({ page: 'asset', slug });
    window.scrollTo(0, 0);
  };
  
  const navigateToCatalog = () => {
    window.location.hash = '/rd-asset-marketplace';
    setRoute({ page: 'catalog' });
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <a href="https://forumoceano.pt/en" className="flex items-center">
              <img 
                src={logoImage} 
                alt="Forum Oceano" 
                className="h-12"
              />
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              <NavItem href="https://forumoceano.pt/en/who-we-are">WHO WE ARE</NavItem>
              <NavItem href="https://forumoceano.pt/en/associates">ASSOCIATES</NavItem>
              <NavItem href="https://forumoceano.pt/en/projects">PROJECTS</NavItem>
              <NavItem href="#/rd-asset-marketplace" active={true}>R&D MARKETPLACE</NavItem>
              <NavItem href="https://forumoceano.pt/en/nautical-stations">NAUTICAL STATIONS</NavItem>
              <NavItem href="https://forumoceano.pt/en/communication">COMMUNICATION</NavItem>
            </nav>

            {/* Right side actions */}
            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-2 px-3 py-1 border border-gray-300 rounded">
                <img 
                  src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 60 30'%3E%3Crect width='60' height='30' fill='%23012169'/%3E%3Cpath d='M0,0 L60,30 M60,0 L0,30' stroke='%23fff' stroke-width='6'/%3E%3Cpath d='M0,0 L60,30 M60,0 L0,30' stroke='%23C8102E' stroke-width='4'/%3E%3Cpath d='M30,0 v30 M0,15 h60' stroke='%23fff' stroke-width='10'/%3E%3Cpath d='M30,0 v30 M0,15 h60' stroke='%23C8102E' stroke-width='6'/%3E%3C/svg%3E"
                  alt="EN"
                  className="w-6 h-4"
                />
                <span className="text-sm font-medium text-gray-700">EN</span>
              </div>

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-gray-700"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="lg:hidden py-4 border-t border-gray-200">
              <nav className="flex flex-col gap-4">
                <MobileNavItem href="https://forumoceano.pt/en/who-we-are">WHO WE ARE</MobileNavItem>
                <MobileNavItem href="https://forumoceano.pt/en/associates">ASSOCIATES</MobileNavItem>
                <MobileNavItem href="https://forumoceano.pt/en/projects">PROJECTS</MobileNavItem>
                <MobileNavItem href="#/rd-asset-marketplace" active={true}>R&D MARKETPLACE</MobileNavItem>
                <MobileNavItem href="https://forumoceano.pt/en/nautical-stations">NAUTICAL STATIONS</MobileNavItem>
                <MobileNavItem href="https://forumoceano.pt/en/communication">COMMUNICATION</MobileNavItem>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="bg-gray-50">
        {route.page === 'catalog' ? (
          <MarketplaceCatalog onNavigateToAsset={navigateToAsset} />
        ) : (
          <AssetDetailPage 
            slug={route.slug}
            asset={cmsAssets.find(a => a.slug === route.slug)}
            onNavigateBack={navigateToCatalog}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#1E3A8A] text-white">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            <div>
              <h3 className="font-semibold text-lg mb-4">ABOUT</h3>
              <p className="text-blue-200 text-sm leading-relaxed">
                Forum Oceano is the managing entity of the Portuguese Sea Cluster, 
                certified by the Ministry of Economy and the Sea.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">QUICK LINKS</h3>
              <ul className="space-y-2 text-sm text-blue-200">
                <li><a href="https://forumoceano.pt/en/who-we-are" className="hover:text-white transition-colors">Who We Are</a></li>
                <li><a href="https://forumoceano.pt/en/associates" className="hover:text-white transition-colors">Associates</a></li>
                <li><a href="https://forumoceano.pt/en/projects" className="hover:text-white transition-colors">Projects</a></li>
                <li><a href="#/rd-asset-marketplace" className="hover:text-white transition-colors">R&D Marketplace</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">R&D MARKETPLACE</h3>
              <ul className="space-y-2 text-sm text-blue-200">
                <li><a href="#/rd-asset-marketplace" className="hover:text-white transition-colors">Browse Assets</a></li>
                <li><a href="#/rd-asset-marketplace?assetType=infrastructure" className="hover:text-white transition-colors">Infrastructure</a></li>
                <li><a href="#/rd-asset-marketplace?assetType=specific-service" className="hover:text-white transition-colors">Services</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">PHASE 2 - COMING SOON</h3>
              <ul className="space-y-2 text-sm text-blue-200">
                <li>Reservation System</li>
                <li>Online Payments</li>
                <li>Bilateral Accounts</li>
                <li>Evaluation System</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-4">CONTACT</h3>
              <ul className="space-y-2 text-sm text-blue-200">
                <li>Doca de Alcântara Norte</li>
                <li>1350-352 Lisboa, Portugal</li>
                <li className="pt-2">
                  <a href="mailto:info@forumoceano.pt" className="hover:text-white transition-colors">
                    info@forumoceano.pt
                  </a>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-blue-700 text-center text-sm text-blue-200">
            © {new Date().getFullYear()} Forum Oceano - Cluster da Economia do Mar. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

function NavItem({ href, children, active = false }: { href: string; children: React.ReactNode; active?: boolean }) {
  return (
    <a
      href={href}
      className={`text-sm font-medium tracking-wide transition-colors relative ${
        active 
          ? 'text-[#00A9A5]' 
          : 'text-[#1E3A8A] hover:text-[#00A9A5]'
      }`}
    >
      {children}
      {active && (
        <span className="absolute -bottom-6 left-0 right-0 h-0.5 bg-[#00A9A5]" />
      )}
    </a>
  );
}

function MobileNavItem({ href, children, active = false }: { href: string; children: React.ReactNode; active?: boolean }) {
  return (
    <a
      href={href}
      className={`text-sm font-medium tracking-wide ${
        active 
          ? 'text-[#00A9A5]' 
          : 'text-[#1E3A8A] hover:text-[#00A9A5]'
      }`}
    >
      {children}
    </a>
  );
}

export default App;