import React, { useState, useEffect, useMemo } from 'react';
import { Search, ChevronDown, X } from 'lucide-react';
import { FilterState } from '../types/cms-schema';
import { cmsAssets, getUniqueInstitutions, getUniqueCities, getAllSkillsTags } from '../data/cms-assets';
import { parseFiltersFromUrl, filtersToUrlParams, applyFilters, getActiveFilterCount } from '../utils/filterUtils';
import { AssetGrid } from '../components/AssetGrid';
import { CompactFilterBar } from '../components/CompactFilterBar';
import heroImage from 'figma:asset/e7b9c669156e36764e38abd448c527cb0f26881c.png';

interface MarketplaceCatalogProps {
  onNavigateToAsset: (slug: string) => void;
}

export function MarketplaceCatalog({ onNavigateToAsset }: MarketplaceCatalogProps) {
  const [filters, setFilters] = useState<FilterState>(() => {
    const searchParams = new URLSearchParams(window.location.search);
    return parseFiltersFromUrl(searchParams);
  });

  // Update URL when filters change
  useEffect(() => {
    const params = filtersToUrlParams(filters);
    const newUrl = params ? `?${params}` : '';
    window.history.replaceState({}, '', `${window.location.pathname}${newUrl}${window.location.hash}`);
  }, [filters]);

  // Apply filters to assets
  const filteredAssets = useMemo(() => {
    return applyFilters(cmsAssets, filters);
  }, [filters]);

  const activeFilterCount = getActiveFilterCount(filters);

  const clearAllFilters = () => {
    setFilters({
      assetType: [],
      subType: [],
      institution: [],
      city: [],
      skillsTags: [],
      requiresTechnicalSupport: null,
      accessScope: [],
      search: ''
    });
  };

  const removeFilter = (key: keyof FilterState, value?: string) => {
    if (key === 'requiresTechnicalSupport') {
      setFilters({ ...filters, requiresTechnicalSupport: null });
    } else if (key === 'search') {
      setFilters({ ...filters, search: '' });
    } else if (value) {
      const currentArray = filters[key] as string[];
      setFilters({ ...filters, [key]: currentArray.filter(v => v !== value) });
    }
  };

  return (
    <div>
      {/* Hero Section - White Background */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-2xl md:text-3xl font-bold text-[#1E3A8A] mb-2">
            R&D Infrastructure Marketplace
          </h1>
          <p className="text-base text-gray-600 max-w-2xl">
            Explore cutting-edge marine research facilities, equipment, and technical services from Hub Azul partner institutions across Portugal.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Compact Filter Bar */}
        <CompactFilterBar
          filters={filters}
          onFilterChange={setFilters}
          institutions={getUniqueInstitutions()}
          cities={getUniqueCities()}
          skillsTags={getAllSkillsTags()}
        />

        {/* Active Filter Chips */}
        {activeFilterCount > 0 && (
          <div className="mb-6 flex flex-wrap items-center gap-2">
            <span className="text-sm font-medium text-[#1E3A8A]">Active filters:</span>
            {filters.search && (
              <FilterChip label={`Search: "${filters.search}"`} onRemove={() => removeFilter('search')} />
            )}
            {filters.assetType.map(v => (
              <FilterChip key={v} label={v} onRemove={() => removeFilter('assetType', v)} />
            ))}
            {filters.subType.map(v => (
              <FilterChip key={v} label={v} onRemove={() => removeFilter('subType', v)} />
            ))}
            {filters.institution.map(v => (
              <FilterChip key={v} label={v} onRemove={() => removeFilter('institution', v)} />
            ))}
            {filters.city.map(v => (
              <FilterChip key={v} label={v} onRemove={() => removeFilter('city', v)} />
            ))}
            {filters.skillsTags.map(v => (
              <FilterChip key={v} label={v} onRemove={() => removeFilter('skillsTags', v)} />
            ))}
            {filters.accessScope.map(v => (
              <FilterChip key={v} label={v} onRemove={() => removeFilter('accessScope', v)} />
            ))}
            {filters.requiresTechnicalSupport !== null && (
              <FilterChip 
                label={filters.requiresTechnicalSupport ? 'With Support' : 'Without Support'} 
                onRemove={() => removeFilter('requiresTechnicalSupport')} 
              />
            )}
            <button
              onClick={clearAllFilters}
              className="text-sm text-[#1E3A8A] hover:text-[#00A9A5] font-medium underline"
            >
              Clear all
            </button>
          </div>
        )}

        {/* Results Header */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-200">
          <div>
            <h2 className="text-xl font-semibold text-[#1E3A8A]">
              {filteredAssets.length} {filteredAssets.length === 1 ? 'Asset' : 'Assets'} Found
            </h2>
          </div>
          
          {filteredAssets.length > 0 && (
            <div className="text-sm text-gray-600">
              {filteredAssets.filter(a => a.featured).length} featured
            </div>
          )}
        </div>

        {/* Asset Grid */}
        {filteredAssets.length > 0 ? (
          <AssetGrid
            assets={filteredAssets}
            onAssetClick={onNavigateToAsset}
          />
        ) : (
          /* Empty State */
          <div className="text-center py-16 px-4">
            <div className="max-w-md mx-auto">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-2xl font-semibold text-[#1E3A8A] mb-2">
                No assets found
              </h3>
              <p className="text-gray-600 mb-6">
                We couldn't find any assets matching your current filters. 
                Try adjusting your search criteria or clearing some filters.
              </p>
              <button
                onClick={clearAllFilters}
                className="px-8 py-3 bg-[#00A9A5] text-white font-medium rounded-lg hover:bg-[#008F8C] transition-colors"
              >
                Clear all filters
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function FilterChip({ label, onRemove }: { label: string; onRemove: () => void }) {
  return (
    <button
      onClick={onRemove}
      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#00A9A5]/10 text-[#00A9A5] border border-[#00A9A5]/30 rounded-full text-sm hover:bg-[#00A9A5]/20 transition-colors font-medium"
    >
      <span>{label}</span>
      <X className="w-3.5 h-3.5" />
    </button>
  );
}