import React, { useState, useEffect } from 'react';
import { ArrowLeft, MapPin, Tag, CheckCircle, XCircle, Clock, FileText, Award, Users, Loader, AlertCircle, Calendar, Mail, CreditCard } from 'lucide-react';
import { Asset, ExternalApiResponse } from '../types/cms-schema';
import { fetchExternalAssetData, getAvailabilityBadgeColor, getAvailabilityLabel } from '../services/externalApi';
import { ContactFormModal } from '../components/ContactFormModal';
import { BookingCalendar } from '../components/BookingCalendar';
import { PaymentModal } from '../components/PaymentModal';

interface AssetDetailPageProps {
  slug: string;
  asset?: Asset;
  onNavigateBack: () => void;
}

export function AssetDetailPage({ slug, asset, onNavigateBack }: AssetDetailPageProps) {
  const [apiData, setApiData] = useState<ExternalApiResponse | null>(null);
  const [apiLoading, setApiLoading] = useState(true);
  const [apiError, setApiError] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedBookingDate, setSelectedBookingDate] = useState<Date | null>(null);
  const [selectedBookingTime, setSelectedBookingTime] = useState<string | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showBookingCalendar, setShowBookingCalendar] = useState(false);

  useEffect(() => {
    if (asset?.externalApiId) {
      setApiLoading(true);
      setApiError(false);
      
      fetchExternalAssetData(asset.externalApiId)
        .then(data => {
          setApiData(data);
          setApiLoading(false);
        })
        .catch(() => {
          setApiError(true);
          setApiLoading(false);
        });
    } else {
      setApiLoading(false);
    }
  }, [asset]);

  if (!asset) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={onNavigateBack}
          className="flex items-center gap-2 text-cyan-700 hover:text-cyan-800 mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Catalog
        </button>
        <div className="text-center py-12">
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Asset Not Found</h2>
          <p className="text-gray-600">The asset you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      'infrastructure': 'Infrastructure',
      'infrastructure-with-support': 'Infrastructure with Mandatory Support',
      'specific-service': 'Specific Service'
    };
    return labels[type] || type;
  };

  const getSubTypeLabel = (subType: string) => {
    const labels: Record<string, string> = {
      'equipment': 'Equipment',
      'laboratory': 'Laboratory',
      'technical-support': 'Technical Support',
      'consulting': 'Consulting Services',
      'analysis': 'Analysis Services'
    };
    return labels[subType] || subType;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <button
        onClick={onNavigateBack}
        className="flex items-center gap-2 text-[#00A9A5] hover:text-[#008F8C] mb-6 transition-colors font-medium"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Back to Catalog</span>
      </button>

      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-wrap gap-3 mb-4">
          <span className="px-4 py-1.5 bg-[#00A9A5]/10 text-[#00A9A5] border border-[#00A9A5]/30 text-sm font-medium rounded-full">
            {getTypeLabel(asset.assetType)}
          </span>
          <span className="px-4 py-1.5 bg-gray-100 text-gray-700 border border-gray-200 text-sm font-medium rounded-full">
            {getSubTypeLabel(asset.subType)}
          </span>
          {asset.requiresTechnicalSupport && (
            <span className="px-4 py-1.5 bg-[#1E3A8A]/10 text-[#1E3A8A] border border-[#1E3A8A]/30 text-sm font-medium rounded-full flex items-center gap-1.5">
              <Users className="w-4 h-4" />
              Technical Support Required
            </span>
          )}
        </div>
        
        <h1 className="text-4xl font-bold text-[#1E3A8A] mb-4">{asset.name}</h1>
        
        <div className="flex items-center gap-2 text-gray-600 mb-6">
          <MapPin className="w-5 h-5 text-[#00A9A5]" />
          <span className="font-medium">{asset.institution}</span>
          <span>·</span>
          <span>{asset.city}, {asset.country || 'Portugal'}</span>
        </div>

        {/* Live Availability Badge */}
        {apiData?.liveAvailability && (
          <div className={`inline-flex items-center gap-2 px-4 py-2 border rounded-lg ${getAvailabilityBadgeColor(apiData.liveAvailability)}`}>
            <div className="w-2 h-2 rounded-full bg-current animate-pulse" />
            <span className="font-medium">{getAvailabilityLabel(apiData.liveAvailability)}</span>
          </div>
        )}
        {apiLoading && (
          <div className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg">
            <Loader className="w-4 h-4 animate-spin text-gray-500" />
            <span className="text-sm text-gray-600">Loading live status...</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="relative h-96 bg-gray-200 rounded-lg overflow-hidden">
              <img
                src={asset.photos[selectedImage]}
                alt={asset.name}
                className="w-full h-full object-cover"
              />
            </div>
            {asset.photos.length > 1 && (
              <div className="grid grid-cols-4 gap-4">
                {asset.photos.map((photo, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`relative h-24 bg-gray-200 rounded-lg overflow-hidden ${
                      selectedImage === index ? 'ring-2 ring-cyan-600' : ''
                    }`}
                  >
                    <img src={photo} alt={`${asset.name} ${index + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Description */}
          <section>
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Description</h2>
            <p className="text-gray-700 leading-relaxed">{asset.description}</p>
          </section>

          {/* Functionalities */}
          <section>
            <h2 className="text-2xl font-semibold text-[#1E3A8A] mb-4">Functionalities</h2>
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {asset.functionalities.map((func, index) => (
                <li key={index} className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-[#00A9A5] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">{func}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* Service Specific Info */}
          {asset.assetType === 'specific-service' && (
            <>
              {asset.serviceMethodology && (
                <section>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">Methodology</h2>
                  <p className="text-gray-700 leading-relaxed">{asset.serviceMethodology}</p>
                </section>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {asset.serviceDeliveryTime && (
                  <InfoCard
                    icon={<Clock className="w-5 h-5" />}
                    title="Delivery Time"
                    content={asset.serviceDeliveryTime}
                  />
                )}
                {asset.serviceCustomization && (
                  <InfoCard
                    icon={<Tag className="w-5 h-5" />}
                    title="Customization"
                    content={asset.serviceCustomization}
                  />
                )}
              </div>
            </>
          )}

          {/* Technical Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {asset.capacityLimitations && (
              <InfoCard
                icon={<AlertCircle className="w-5 h-5" />}
                title="Capacity & Limitations"
                content={asset.capacityLimitations}
              />
            )}
            {asset.accessibility && (
              <InfoCard
                icon={<Users className="w-5 h-5" />}
                title="Accessibility"
                content={asset.accessibility}
              />
            )}
            <InfoCard
              icon={<Calendar className="w-5 h-5" />}
              title="Availability"
              content={asset.availability}
            />
            <InfoCard
              icon={<FileText className="w-5 h-5" />}
              title="Conditions of Use"
              content={asset.conditionsOfUse}
            />
          </div>

          {/* Skills & Tags */}
          <section>
            <h2 className="text-2xl font-semibold text-[#1E3A8A] mb-4">Skills & Specializations</h2>
            <div className="flex flex-wrap gap-2">
              {asset.skillsTags.map((tag, index) => (
                <span
                  key={index}
                  className="px-4 py-2 bg-[#00A9A5]/10 text-[#00A9A5] border border-[#00A9A5]/30 text-sm font-medium rounded-lg"
                >
                  {tag}
                </span>
              ))}
            </div>
          </section>

          {/* Downloads */}
          {(asset.technicalFiles?.length || asset.certificates?.length) && (
            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Downloads & Certifications</h2>
              <div className="space-y-4">
                {asset.technicalFiles && asset.technicalFiles.length > 0 && (
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Technical Files</h3>
                    <div className="space-y-2">
                      {asset.technicalFiles.map((file, index) => (
                        <a
                          key={index}
                          href={file.url}
                          className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <FileText className="w-5 h-5 text-gray-500" />
                          <span className="text-sm text-gray-700">{file.name}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
                
                {asset.certificates && asset.certificates.length > 0 && (
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Certificates & Accreditations</h3>
                    <div className="flex flex-wrap gap-2">
                      {asset.certificates.map((cert, index) => (
                        <a
                          key={index}
                          href={cert.url}
                          className="inline-flex items-center gap-2 px-4 py-2 bg-green-50 text-green-800 border border-green-200 rounded-lg hover:bg-green-100 transition-colors"
                        >
                          <Award className="w-4 h-4" />
                          <span className="text-sm font-medium">{cert.name}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </section>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Booking Card */}
          <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-lg text-[#1E3A8A] mb-4">Interested in this asset?</h3>
            
            {!showBookingCalendar ? (
              <>
                <button
                  onClick={() => setShowBookingCalendar(true)}
                  className="w-full px-6 py-3 bg-[#00A9A5] text-white font-medium rounded-lg hover:bg-[#008F8C] transition-colors flex items-center justify-center gap-2 mb-3"
                >
                  <CreditCard className="w-5 h-5" />
                  Book Now
                </button>
                <button
                  onClick={() => setShowContactForm(true)}
                  className="w-full px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
                >
                  <Mail className="w-5 h-5" />
                  Request Information
                </button>
                <p className="text-xs text-gray-600 mt-3 text-center">
                  Our team will respond within 24 hours
                </p>
              </>
            ) : (
              <div className="space-y-4">
                <BookingCalendar
                  selectedDate={selectedBookingDate}
                  selectedTime={selectedBookingTime}
                  onDateSelect={(date) => {
                    setSelectedBookingDate(date);
                    setSelectedBookingTime('09:00'); // Set default time
                    setShowPaymentModal(true); // Show payment modal immediately
                  }}
                  onTimeSelect={setSelectedBookingTime}
                />
                
                <button
                  onClick={() => {
                    setShowBookingCalendar(false);
                    setSelectedBookingDate(null);
                    setSelectedBookingTime(null);
                  }}
                  className="w-full text-sm text-gray-600 hover:text-gray-800 transition-colors"
                >
                  ← Back
                </button>
              </div>
            )}
          </div>

          {/* External API Data */}
          {apiData && (
            <div className="bg-gradient-to-br from-[#00A9A5]/10 to-blue-50 border border-[#00A9A5]/30 rounded-lg p-6">
              <h3 className="font-semibold text-[#1E3A8A] mb-4">Live Information</h3>
              <dl className="space-y-3 text-sm">
                {apiData.lastCalibrationDate && (
                  <div>
                    <dt className="text-gray-600">Last Calibration</dt>
                    <dd className="font-medium text-[#1E3A8A]">
                      {new Date(apiData.lastCalibrationDate).toLocaleDateString('en-GB')}
                    </dd>
                  </div>
                )}
                {apiData.nextMaintenanceDate && (
                  <div>
                    <dt className="text-gray-600">Next Maintenance</dt>
                    <dd className="font-medium text-[#1E3A8A]">
                      {new Date(apiData.nextMaintenanceDate).toLocaleDateString('en-GB')}
                    </dd>
                  </div>
                )}
                {apiData.realTimeMetadata && Object.entries(apiData.realTimeMetadata).map(([key, value]) => (
                  <div key={key}>
                    <dt className="text-gray-600 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</dt>
                    <dd className="font-medium text-[#1E3A8A]">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}

          {apiError && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-yellow-800">
                  <p className="font-medium mb-1">Live data unavailable</p>
                  <p>Some real-time information couldn't be loaded. Please contact us for current status.</p>
                </div>
              </div>
            </div>
          )}

          {/* Metadata */}
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
            <h3 className="font-semibold text-[#1E3A8A] mb-4">Details</h3>
            <dl className="space-y-3 text-sm">
              <div>
                <dt className="text-gray-600">Access Scope</dt>
                <dd className="font-medium text-[#1E3A8A] capitalize">{asset.accessScope.replace('-', ' ')}</dd>
              </div>
              <div>
                <dt className="text-gray-600">Last Updated</dt>
                <dd className="font-medium text-[#1E3A8A]">
                  {new Date(asset.lastUpdated).toLocaleDateString('en-GB')}
                </dd>
              </div>
              {asset.externalApiId && (
                <div>
                  <dt className="text-gray-600">Asset ID</dt>
                  <dd className="font-mono text-xs text-gray-700">{asset.externalApiId}</dd>
                </div>
              )}
            </dl>
          </div>
        </div>
      </div>

      {/* Contact Form Modal */}
      {showContactForm && (
        <ContactFormModal
          asset={asset}
          onClose={() => setShowContactForm(false)}
        />
      )}

      {/* Payment Modal */}
      {showPaymentModal && selectedBookingDate && selectedBookingTime && (
        <PaymentModal
          asset={asset}
          selectedDate={selectedBookingDate}
          selectedTime={selectedBookingTime}
          onClose={() => setShowPaymentModal(false)}
          onConfirm={() => {
            setSelectedBookingDate(null);
            setSelectedBookingTime(null);
          }}
        />
      )}
    </div>
  );
}

function InfoCard({ icon, title, content }: { icon: React.ReactNode; title: string; content: string }) {
  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-5">
      <div className="flex items-center gap-2 mb-2 text-gray-700">
        {icon}
        <h3 className="font-semibold">{title}</h3>
      </div>
      <p className="text-sm text-gray-700 leading-relaxed">{content}</p>
    </div>
  );
}