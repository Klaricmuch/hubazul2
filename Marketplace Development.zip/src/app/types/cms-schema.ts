/**
 * CMS Schema for R&D Asset Marketplace
 * 
 * This schema defines the data structure for assets in the marketplace.
 * Assets can be managed through a headless CMS (Airtable, Contentful, etc.)
 */

export type AssetType = 'infrastructure' | 'infrastructure-with-support' | 'specific-service';
export type SubType = 'equipment' | 'laboratory' | 'technical-support' | 'consulting' | 'analysis';
export type AccessScope = 'hub-only' | 'external' | 'both';

export interface Asset {
  // Core identifiers
  id: string;
  slug: string;
  name: string;
  
  // Classification
  assetType: AssetType;
  subType: SubType;
  requiresTechnicalSupport: boolean;
  accessScope: AccessScope;
  
  // Location
  institution: string;
  city: string;
  country?: string;
  
  // Content
  description: string;
  functionalities: string[];
  capacityLimitations?: string;
  accessibility?: string;
  availability: string;
  conditionsOfUse: string;
  
  // Tags and categorization
  skillsTags: string[];
  
  // Media
  photos: string[];
  technicalFiles?: FileAttachment[];
  certificates?: FileAttachment[];
  
  // Service-specific fields
  serviceMethodology?: string;
  serviceDeliveryTime?: string;
  serviceCustomization?: string;
  
  // API integration
  externalApiId?: string;
  
  // Metadata
  lastUpdated: string;
  featured?: boolean;
  publishedAt?: string;
}

export interface FileAttachment {
  name: string;
  url: string;
  type: string;
  size?: number;
}

export interface ContactSubmission {
  name: string;
  entity: string;
  email: string;
  assetSlug: string;
  assetName: string;
  message: string;
  files?: File[];
  timestamp: string;
  pageUrl: string;
}

export interface ExternalApiResponse {
  assetId: string;
  liveAvailability?: 'available' | 'booked' | 'maintenance';
  lastCalibrationDate?: string;
  nextMaintenanceDate?: string;
  ownerContact?: string;
  realTimeMetadata?: Record<string, any>;
}

export interface FilterState {
  assetType: string[];
  subType: string[];
  institution: string[];
  city: string[];
  skillsTags: string[];
  requiresTechnicalSupport: boolean | null;
  accessScope: string[];
  search: string;
}
